package com.monabbeh.app;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final Locale AR = new Locale("ar", "EG");

    private final SimpleDateFormat dateFmt = new SimpleDateFormat("EEE d MMM yyyy", AR);
    private final SimpleDateFormat timeFmt = new SimpleDateFormat("hh:mm a", AR);
    private final SimpleDateFormat fullFmt = new SimpleDateFormat("EEEE d MMMM yyyy - hh:mm a", AR);

    private final Calendar selected = Calendar.getInstance();

    private EditText labelInput;
    private Button dateBtn;
    private Button timeBtn;
    private Button stopRingBtn;
    private AlarmAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        labelInput = findViewById(R.id.labelInput);
        dateBtn = findViewById(R.id.dateBtn);
        timeBtn = findViewById(R.id.timeBtn);
        stopRingBtn = findViewById(R.id.stopRingBtn);

        selected.add(Calendar.HOUR_OF_DAY, 1);
        selected.set(Calendar.SECOND, 0);
        selected.set(Calendar.MILLISECOND, 0);
        updateButtons();

        dateBtn.setOnClickListener(v -> new DatePickerDialog(this,
                (view, y, m, d) -> {
                    selected.set(y, m, d);
                    updateButtons();
                },
                selected.get(Calendar.YEAR), selected.get(Calendar.MONTH),
                selected.get(Calendar.DAY_OF_MONTH)).show());

        timeBtn.setOnClickListener(v -> new TimePickerDialog(this,
                (view, h, min) -> {
                    selected.set(Calendar.HOUR_OF_DAY, h);
                    selected.set(Calendar.MINUTE, min);
                    selected.set(Calendar.SECOND, 0);
                    selected.set(Calendar.MILLISECOND, 0);
                    updateButtons();
                },
                selected.get(Calendar.HOUR_OF_DAY), selected.get(Calendar.MINUTE),
                DateFormat.is24HourFormat(this)).show());

        findViewById(R.id.quick10).setOnClickListener(v -> setAfterMinutes(10));
        findViewById(R.id.quick30).setOnClickListener(v -> setAfterMinutes(30));
        findViewById(R.id.quick60).setOnClickListener(v -> setAfterMinutes(60));

        findViewById(R.id.addBtn).setOnClickListener(v -> addAlarm());

        stopRingBtn.setOnClickListener(v -> {
            startService(new Intent(this, AlarmService.class).setAction(AlarmService.ACTION_STOP));
            stopRingBtn.setVisibility(View.GONE);
        });

        adapter = new AlarmAdapter();
        ListView list = findViewById(R.id.list);
        list.setEmptyView(findViewById(R.id.empty));
        list.setAdapter(adapter);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        stopRingBtn.setVisibility(AlarmService.ringing ? View.VISIBLE : View.GONE);
    }

    private void setAfterMinutes(int minutes) {
        selected.setTimeInMillis(System.currentTimeMillis() + minutes * 60000L);
        updateButtons();
    }

    private void updateButtons() {
        Date d = selected.getTime();
        dateBtn.setText(dateFmt.format(d));
        timeBtn.setText(timeFmt.format(d));
    }

    private void addAlarm() {
        String label = labelInput.getText().toString().trim();
        if (label.isEmpty()) label = getString(R.string.default_label);

        long t = selected.getTimeInMillis();
        if (t <= System.currentTimeMillis()) {
            Toast.makeText(this, R.string.past_time, Toast.LENGTH_SHORT).show();
            return;
        }
        AlarmStore.Item it = AlarmStore.add(this, label, t);
        AlarmScheduler.schedule(this, it);
        labelInput.setText("");
        Toast.makeText(this, getString(R.string.alarm_set) + "\n" + fullFmt.format(new Date(t)),
                Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void refresh() {
        adapter.set(AlarmStore.load(this));
    }

    private class AlarmAdapter extends BaseAdapter {
        private List<AlarmStore.Item> data = new ArrayList<>();

        void set(List<AlarmStore.Item> d) {
            data = d;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return data.get(position).id;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            if (row == null) {
                row = getLayoutInflater().inflate(R.layout.item_alarm, parent, false);
            }
            final AlarmStore.Item it = data.get(position);
            ((TextView) row.findViewById(R.id.itemLabel)).setText(it.label);
            ((TextView) row.findViewById(R.id.itemTime)).setText(fullFmt.format(new Date(it.time)));
            row.findViewById(R.id.itemDelete).setOnClickListener(x -> {
                AlarmScheduler.cancel(MainActivity.this, it.id);
                AlarmStore.remove(MainActivity.this, it.id);
                refresh();
            });
            return row;
        }
    }
}
