package com.monabbeh.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

/** شاشة الرنين: بتظهر فوق شاشة القفل وفيها زر إيقاف وزر غفوة. */
public class RingActivity extends Activity {

    private TextView labelView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT < 27) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_ring);

        labelView = findViewById(R.id.ringLabel);
        showLabel(getIntent());

        findViewById(R.id.stopBtn).setOnClickListener(v -> send(AlarmService.ACTION_STOP));
        findViewById(R.id.snoozeBtn).setOnClickListener(v -> send(AlarmService.ACTION_SNOOZE));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        showLabel(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // لو الرنين وقف، مفيش داعي تفضل الشاشة مفتوحة
        if (!AlarmService.ringing) finish();
    }

    private void showLabel(Intent i) {
        String label = i.getStringExtra("label");
        labelView.setText(label == null ? "" : label);
    }

    private void send(String action) {
        Intent i = new Intent(this, AlarmService.class)
                .setAction(action)
                .putExtra("label", getIntent().getStringExtra("label"));
        startService(i);
        finish();
    }
}
