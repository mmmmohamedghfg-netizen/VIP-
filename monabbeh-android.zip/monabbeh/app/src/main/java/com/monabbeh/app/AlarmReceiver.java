package com.monabbeh.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** بيستقبل وقت المنبه ويشغّل خدمة الرنين. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent s = new Intent(context, AlarmService.class);
        s.putExtra("id", intent.getLongExtra("id", 0));
        s.putExtra("label", intent.getStringExtra("label"));
        context.startForegroundService(s);
    }
}
