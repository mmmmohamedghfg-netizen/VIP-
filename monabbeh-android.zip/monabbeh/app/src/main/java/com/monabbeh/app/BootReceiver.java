package com.monabbeh.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** بعد إعادة تشغيل الجهاز أو تحديث التطبيق: بيرجّع جدولة المنبهات الجاية. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        long now = System.currentTimeMillis();
        for (AlarmStore.Item it : AlarmStore.load(context)) {
            if (it.time > now) {
                AlarmScheduler.schedule(context, it);
            } else {
                AlarmStore.remove(context, it.id);
            }
        }
    }
}
