package com.monabbeh.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** جدولة المنبه عن طريق AlarmManager.setAlarmClock (دقيق، ومش بيتأثر بتوفير البطارية). */
public class AlarmScheduler {

    static final String ACTION = "com.monabbeh.app.ALARM";

    private static PendingIntent pending(Context c, long id, String label) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION);
        i.putExtra("id", id);
        i.putExtra("label", label);
        return PendingIntent.getBroadcast(
                c, (int) (id & 0x7fffffff), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c, AlarmStore.Item it) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(
                c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(it.time, show), pending(c, it.id, it.label));
    }

    public static void cancel(Context c, long id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pending(c, id, null));
    }
}
