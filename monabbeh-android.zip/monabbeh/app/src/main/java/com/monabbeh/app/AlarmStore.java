package com.monabbeh.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/** تخزين بسيط للمنبهات في SharedPreferences بصيغة JSON. */
public class AlarmStore {

    public static class Item {
        public long id;
        public String label;
        public long time; // وقت الرنين بالمللي ثانية
    }

    private static final String PREFS = "alarms";
    private static final String KEY = "list";

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized List<Item> load(Context c) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Item it = new Item();
                it.id = o.getLong("id");
                it.label = o.getString("label");
                it.time = o.getLong("time");
                out.add(it);
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, (a, b) -> Long.compare(a.time, b.time));
        return out;
    }

    private static void save(Context c, List<Item> list) {
        JSONArray arr = new JSONArray();
        for (Item it : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("id", it.id);
                o.put("label", it.label);
                o.put("time", it.time);
                arr.put(o);
            } catch (JSONException ignored) {
            }
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }

    public static synchronized Item add(Context c, String label, long time) {
        List<Item> list = load(c);
        Item it = new Item();
        it.id = System.currentTimeMillis();
        it.label = label;
        it.time = time;
        list.add(it);
        save(c, list);
        return it;
    }

    public static synchronized void remove(Context c, long id) {
        List<Item> list = load(c);
        Iterator<Item> iter = list.iterator();
        while (iter.hasNext()) {
            if (iter.next().id == id) iter.remove();
        }
        save(c, list);
    }
}
