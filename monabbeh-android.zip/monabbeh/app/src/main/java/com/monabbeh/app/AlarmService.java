package com.monabbeh.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** خدمة الرنين: بتشغّل الصوت والاهتزاز في loop لحد ما تضغط إيقاف. */
public class AlarmService extends Service {

    static final String ACTION_STOP = "com.monabbeh.app.STOP";
    static final String ACTION_SNOOZE = "com.monabbeh.app.SNOOZE";
    static final String CHANNEL = "alarm_ring";
    static final int NOTIF_ID = 1001;
    static final long SNOOZE_MS = 10 * 60 * 1000L;

    /** MainActivity و RingActivity بيستخدموه يعرفوا إن في رنين شغال. */
    static volatile boolean ringing = false;

    private MediaPlayer player;
    private Vibrator vibrator;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        String label = intent != null ? intent.getStringExtra("label") : null;
        if (label == null) label = "";

        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_SNOOZE.equals(action)) {
            AlarmStore.Item it = AlarmStore.add(this, label, System.currentTimeMillis() + SNOOZE_MS);
            AlarmScheduler.schedule(this, it);
            stopSelf();
            return START_NOT_STICKY;
        }

        // رنين جديد
        ringing = true;
        AlarmStore.remove(this, intent != null ? intent.getLongExtra("id", 0) : 0);
        startForegroundCompat(buildNotification(label));
        startRinging();
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String label) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

        Intent ring = new Intent(this, RingActivity.class)
                .putExtra("label", label)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullScreen = PendingIntent.getActivity(this, 2, ring, piFlags);

        Intent stop = new Intent(this, AlarmService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 3, stop, piFlags);

        Intent snooze = new Intent(this, AlarmService.class).setAction(ACTION_SNOOZE)
                .putExtra("label", label);
        PendingIntent snoozePi = PendingIntent.getService(this, 4, snooze, piFlags);

        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat_alarm);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(label)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setFullScreenIntent(fullScreen, true)
                .setContentIntent(fullScreen)
                .addAction(new Notification.Action.Builder(icon, getString(R.string.stop), stopPi).build())
                .addAction(new Notification.Action.Builder(icon, getString(R.string.snooze), snoozePi).build())
                .build();
    }

    private void startForegroundCompat(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void startRinging() {
        stopRinging();

        // نتأكد إن صوت المنبه مش صفر
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            int min = (int) Math.ceil(max * 0.6);
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < min) {
                am.setStreamVolume(AudioManager.STREAM_ALARM, min, 0);
            }
        } catch (Exception ignored) {
        }

        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            player.setDataSource(this, uri);
            player.setLooping(true);
            player.prepare();
            player.start();
        } catch (Exception e) {
            if (player != null) {
                player.release();
                player = null;
            }
        }

        try {
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) {
                vibrator.vibrate(
                        VibrationEffect.createWaveform(new long[]{0, 700, 700}, 0),
                        new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            }
        } catch (Exception ignored) {
        }
    }

    private void stopRinging() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
        if (vibrator != null) {
            vibrator.cancel();
        }
    }

    @Override
    public void onDestroy() {
        stopRinging();
        ringing = false;
        super.onDestroy();
    }
}
